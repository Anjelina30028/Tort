<footer>
    <div class="footer-logo">
        <a href="/"><img src="svg/logo.svg" alt="" /></a>
        <p>Ⓒ 2024 Будешь торт?</p>
    </div>
    <nav>
        <div><a href="/catalog">Каталог</a></div>
        <div><a href="/sales">Акции</a></div>
        <div><a href="/delivery">Доставка и оплата</a></div>
        <div><a href="/contacts">Контакты</a></div>
    </nav>
    <div class="footer-social">
        <p>Мы в соцсетях</p>
        <a href="/error">Вконтакте</a>
        <a href="/error">Телеграмм</a>
    </div>
</footer>