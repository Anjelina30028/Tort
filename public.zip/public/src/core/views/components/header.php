<header>
    <a href="/"><img src="/svg/Logo.svg" alt="" /></a>
    <nav>
        <a href="/catalog">Каталог</a>
        <a href="/sales">Акции</a>
        <a href="/delivery">Доставка и оплата</a>
        <a href="/contacts">Контакты</a>
        <?if(isset($_SESSION['user']) && $_SESSION['user']['role'] == 'admin'):?>
            <a href="/admin">Админ. панель</a>
        <?endif;?>
    </nav>
    <div class="header-icons">
        <a href="/error"><img src="/svg/star.svg" alt="" /></a>
        <a href="/cart"><img src="/svg/shopping bag.svg" alt="" /></a>
         <?if(isset($_SESSION['user'])):?>
            <form action="/quit" method="post">
                <button><img src="/svg/logout.svg" alt="" /></button>
            </form>
            <?else:?>
            <a href="/login"><img src="/svg/person.svg" alt="" /></a>
            <?endif;?>
    </div>
</header>